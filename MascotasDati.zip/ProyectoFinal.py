import tkinter
from mascota import *
import threading as th
from tkinter import *
import json

r = ''
i = 0
j = 20
band = 0

hilos = {
        'hilo1_hambre': None,
        'hilo2_diver': None
    }

win = Tk()
win.title('Mascotas Dati')
win.geometry('520x520')
win.resizable(False, False)

imgfondo=PhotoImage(file='mascotadati.png')
huevo=PhotoImage(file='huevo.png')
fondo=PhotoImage(file='fondodati.png')

perritoalimetado=PhotoImage(file='iperrito/perritalimentado.png')
perritoaburrido=PhotoImage(file='iperrito/perritoaburrido.png')
perritocontento=PhotoImage(file='iperrito/perritocontento.png')
perritocurado=PhotoImage(file='iperrito/perritocurado.png')
perritodannado=PhotoImage(file='iperrito/perritodannado.png')
perritohambriento=PhotoImage(file='iperrito/perritohambriento.png')

dragonaburrido=PhotoImage(file='idragon/dragonaburrido.png')
dragonalimentado=PhotoImage(file='idragon/dragonalimentado.png')
dragoncontento=PhotoImage(file='idragon/dragoncontento.png')
dragoncurado=PhotoImage(file='idragon/dragoncurado.png')
dragondannado=PhotoImage(file='idragon/dragondannado.png')
dragonhambre=PhotoImage(file='idragon/drgonhambre.png')

gatoaburrido=PhotoImage(file='igato/gatoaburrido.png')
gatoalimentado=PhotoImage(file='igato/gatoalimentado.png')
gatocontento=PhotoImage(file='igato/gatocontento.png')
gatocurado=PhotoImage(file='igato/gatocurado.png')
gatoadannado=PhotoImage(file='igato/gatodannado.png')
gatohambriento=PhotoImage(file='igato/gatphambriento.png')



def iniciar_hilo1():
    global hilos, mascota1
    mascota1.generar_hambre()
    hilos['hilo1_hambre'] = th.Timer(10, iniciar_hilo1)
    if mascota1.salud > 0:
        hilos['hilo1_hambre'].start()
    else:
        hilos['hilo1_hambre'].cancel()

def iniciar_hilo2():
    global hilos, mascota1
    mascota1.generar_aburrimiento()
    hilos['hilo2_diver'] = th.Timer(10, iniciar_hilo2)
    if mascota1.salud > 0:
        hilos['hilo2_diver'].start()
    else:
        hilos['hilo2_diver'].cancel()

def detener_hilos():
    global hilos
    hilos['hilo1_hambre'].cancel()
    hilos['hilo2_diver'].cancel()

def Cleantk():
    background = Label(image=imgfondo)
    background.place(x=0, y=0, relwidth=1, relheight=1)

def Cleantk2():
    background = Label(image=fondo)
    background.place(x=0, y=0, relwidth=1, relheight=1)

def Menutk():
    Cleantk()
    btn_conti = Button(win, text='Continuar', padx=10, pady=10, command=Continuar)
    btn_conti.place(x=220, y=270)

    btn_juegN = Button(win, text='Juego nuevo', padx=10, pady=10, command=lambda: actualizar_etiqueta(random.randint(5,10)))
    btn_juegN.place(x=210, y=330)

    btn_salir = Button(win, text='Salir', padx=10, pady=10, command=win.destroy)
    btn_salir.place(x=230, y=390)

def Continuar(): #continuar
    Cleantk2()
    lbl_1 = Label(win, text='Seleccione la partida\n que desea continuar', font=('Arial Bold', 26), bg='#FCE297', fg='#9A6315')
    lbl_1.place(x=110, y=20)

    btn_P1 = Button(win, text='Partida 1', padx=10, pady=10, command=lambda: Registrar('1') )
    btn_P1.place(x=220, y=110)

    btn_P2 = Button(win, text='Partida 2', padx=10, pady=10, command=lambda : Registrar('2'))
    btn_P2.place(x=220, y=170)

    btn_P3 = Button(win, text='Partida 3', padx=10, pady=10, command=lambda : Registrar('3'))
    btn_P3.place(x=220, y=230)

    btn_P4 = Button(win, text='Partida 4', padx=10, pady=10, command=lambda : Registrar('4'))
    btn_P4.place(x=220, y=290)

    btn_P5 = Button(win, text='Partida 5', padx=10, pady=10, command=lambda : Registrar('5'))
    btn_P5.place(x=220, y=350)

    btn_P6 = Button(win, text='Partida 6', padx=10, pady=10, command=lambda : Registrar('6'))
    btn_P6.place(x=220, y=410)

    btn_r =Button(win, text='Regresar', padx=10, pady=10, command= Menutk)
    btn_r.place(x=220, y=470)

def Crearmasc(nombremas):
    global mascota1
    jojo = random.randint(1, 3)
    if jojo == 1:
        mascota1 = gordo()
        mascota1.incubar(str(nombremas))
        print('Mascota tipo gordo')
    elif jojo == 2:
        mascota1 = atletico()
        mascota1.incubar(str(nombremas))
        print('Mascota tipo atletico')
    elif jojo == 3:
        mascota1 = hiperactivo()
        mascota1.incubar(str(nombremas))
        print('Mascota tipo hiperactivo')
    Nuevamascota()#llamar al timer


def actualizar_etiqueta(numero_aleatorio): #hace el conteo en pantalla de la mascota
    if numero_aleatorio > 0:
        btn_cas = Button(win, image=huevo ,command=lambda : actualizar_etiqueta(numero_aleatorio-1))
        btn_cas.place(x=0, y=0)
    else:
        Nombremascot()


def Nuevamascota():
    global mascota1
    Cleantk2()
    lbl_fel= Label(win, text='¡Enhorabuena \n ha nacido la mascota!', font=('Arial Bold', 20), bg='#FCE297', fg='#9A6315' )
    lbl_fel.place(x=115, y=70)
    lbl_tipo = Label(win, text='Mascota tipo: \n' + str(mascota1.tipo), font=('Arial Bold', 20), bg='#FCE297', fg='#9A6315')
    lbl_tipo.place(x=175, y=220)
    btn_jugar = Button(win, text='Continuar', command=antessubMenu)
    btn_jugar.place(x=300, y=400)

def Nombremascot():
    global mascota1
    Cleantk()
    lbl_nom = Label(win, text='Escriba el nombre \n de la nueva mascota: ', font=('Arial Bold', 16), bg='#FCE297', fg='#9A6315')
    lbl_nom.place(x=150, y=240)
    nomb = Entry(win, justify=LEFT)
    nomb.place(x=200, y=300)
    nombr = nomb.get()
    print('nombre de la mascota: ', nombr)
    btn_Pajuego = Button(win, text='Siguiente', command=lambda: Crearmasc(nomb.get()))
    btn_Pajuego.place(x=350, y=440)

def Registrar(a):
    if a == '1':
        try:
            a1 = open('slots/slot1.txt', 'r')
            arr1 = json.load(a1)
            cargar(arr1)
            antessubMenu()
        except:
            print('Sin datos guardados')

    elif a == '2':
        try:
            a2 = open('slots/slot2.txt', 'r')
            arr1 = json.load(a2)
            cargar(arr1)
            antessubMenu()
        except:
            print('Sin datos guardados')

    elif a == '3':
        try:
            a3 = open('slots/slot3.txt', 'r')
            arr1 = json.load(a3)
            cargar(arr1)
            antessubMenu()
        except:
            print('Sin datos guardados')

    elif a == '4':
        try:
            a4 = open('slots/slot4.txt', 'r')
            arr1 = json.load(a4)
            cargar(arr1)
            antessubMenu()
        except:
            print('Sin datos guardados')

    elif a == '5':
        try:
            a5 = open('slots/slot5.txt', 'r')
            arr1 = json.load(a5)
            cargar(arr1)
            antessubMenu()
        except:
            print('Sin datos guardados')

    elif a == '6':
        try:
            a6 = open('slots/sloslot6.txt', 'r')
            arr1 = json.load(a6)
            cargar(arr1)
            antessubMenu()
        except:
            print('Sin datos guardados')

    else:
        print('Opción inválida')

def antessubMenu():
    iniciar_hilo1()
    iniciar_hilo2()
    lbl_mascota = Label(win)
    lbl_mascota.place(x=0, y=0, relwidth=1, relheight=1)
    if mascota1.tipo == 'gordo':
        lbl_mascota.configure(image=gatocontento)
    elif mascota1.tipo == 'hiperactivo':
        lbl_mascota.configure(image=dragoncontento)
    elif mascota1.tipo == 'atletico':
        lbl_mascota.configure(image=perritocontento)
    mostrardat()
    subMenu()

def subMenu():
    btn_ali = Button(win, text='Alimentar', padx=20, pady=10, command=lambda : refresh(1))
    btn_ali.place(x=20, y=470)
    btn_ju = Button(win, text='Jugar', padx=20,pady=10, command=lambda : refresh(2))
    btn_ju.place(x=130, y=470)
    btn_vet = Button(win, text='Veterinario', padx=20, pady=10, command=lambda: refresh(3))
    btn_vet.place(x=220, y=470)
    btn_ree = Button(win, text='Refresh', padx=20, pady=10, command=lambda : refresh(4))
    btn_ree.place(x=340, y=470)
    btn_r = Button(win, text='Regresar', padx=10, pady=10, command=lambda: [detener_hilos,slotsGuard('')])
    btn_r.place(x=440, y=8)

def mostrardat():
    lbl_nomb = Label(win, text='Nombre: ' + mascota1.nombre, bg='#FCE297', fg='#9A6315')
    lbl_nomb.grid(column=0, row=0)
    lbl_sal = Label(win, text='Salud: ' + str(round(mascota1.salud)), bg='#FCE297', fg='#9A6315')
    lbl_sal.grid(column=0, row=1)
    lbl_ham = Label(win, text='Hambre: ' + str(round(mascota1.hambre)), bg='#FCE297', fg='#9A6315')
    lbl_ham.grid(column=0, row=2)
    lbl_div = Label(win, text='Diversión: ' + str(round(mascota1.diversion)), bg='#FCE297', fg='#9A6315')
    lbl_div.grid(column=0, row=3)


def refresh(a):
    lbl_mascota = Label(win)
    lbl_mascota.place(x=0, y=0, relwidth=1, relheight=1)
    if mascota1.salud <= 0:
        Cleantk2()
        detener_hilos()
        slotsGuard('dead')
    else:
        if a == 1:
            mascota1.alimentar()
            mostrardat()
        elif a ==2:
            mascota1.jugar()
            mostrardat()
        elif a == 3:
            mascota1.vet()
            mostrardat()
        elif a == 4:
            mostrardat()
        if mascota1.tipo == 'gordo':
            if mascota1.diversion > 50:
                lbl_mascota.configure(image=gatocontento)  # si esta divertido
            if mascota1.hambre < 50:
                lbl_mascota.configure(image=gatoalimentado)  # si esta bien alimentado
            if mascota1.salud > 50:
                lbl_mascota.configure(image=gatocurado)  # si tiene buena salud
            if mascota1.diversion > 50 and mascota1.hambre < 50 and mascota1.salud > 50:
                a = random.randint(1, 2)
                if a == 1:
                    lbl_mascota.configure(image=gatocontento)
                elif a == 2:
                    lbl_mascota.configure(image=gatoalimentado)
            if mascota1.diversion < 50:
                lbl_mascota.configure(image=gatoaburrido)  # si esta aburrido
            if mascota1.hambre > 50:
                lbl_mascota.configure(image=gatohambriento)  # si tiene mala hambre
            if mascota1.salud < 50:
                lbl_mascota.configure(image=gatoadannado)  # si tiene mala salud

        elif mascota1.tipo == 'hiperactivo':
            if mascota1.diversion > 50:
                lbl_mascota.configure(image=dragoncontento)  # si esta divertido
            if mascota1.hambre < 50:
                lbl_mascota.configure(image=dragonalimentado)  # si esta bien alimentado
            if mascota1.salud > 50:
                lbl_mascota.configure(image=dragoncurado)  # si tiene buena salud
            if mascota1.diversion > 50 and mascota1.hambre < 50 and mascota1.salud > 50:
                a = random.randint(1, 2)
                if a == 1:
                    lbl_mascota.configure(image=dragoncontento)
                elif a == 2:
                    lbl_mascota.configure(image=dragonalimentado)
            if mascota1.diversion < 50:
                lbl_mascota.configure(image=dragonaburrido)  # si esta aburrido
            if mascota1.hambre > 50:
                lbl_mascota.configure(image=dragonhambre)  # si tiene mala hambre
            if mascota1.salud < 50:
                lbl_mascota.configure(image=dragondannado)  # si tiene mala salud
        elif mascota1.tipo == 'atletico':
            if mascota1.diversion > 50:
                lbl_mascota.configure(image=perritocontento)#si esta divertido
            if mascota1.hambre < 50:
                lbl_mascota.configure(image=perritoalimetado)#si esta bien alimentado
            if mascota1.salud > 50:
                lbl_mascota.configure(image=perritocurado)#si tiene buena salud
            if mascota1.diversion > 50 and mascota1.hambre < 50 and mascota1.salud > 50:
                a = random.randint(1,2)
                if a == 1:
                    lbl_mascota.configure(image=perritocontento)
                elif a == 2:
                    lbl_mascota.configure(image=perritoalimetado)
            if mascota1.diversion < 50:
                lbl_mascota.configure(image=perritoaburrido)#si esta aburrido
            if mascota1.hambre > 50:
                lbl_mascota.configure(image=perritohambriento)#si tiene mala hambre
            if mascota1.salud < 50:
                lbl_mascota.configure(image=perritodannado)#si tiene mala salud
        subMenu()

def slotsGuard(a):
    Cleantk2()
    if a == 'dead':
        lbl_1 = Label(win, text=mascota1.nombre +' ha muerto \nSeleccione el espacio de guardado', font=('Arial Bold', 24), bg='#FCE297', fg='#996416')
        lbl_1.place(x=15, y=10)
    else:
        lbl_1 = Label(win, text='Seleccione el espacio \n de guardado', font=('Arial Bold', 24), bg='#FCE297', fg='#996416')
        lbl_1.place(x=100, y=10)

    btn_P1 = Button(win, text='Partida 1', padx=10, pady=10, command=lambda: guardarPart('1'))
    btn_P1.place(x=220, y=110)

    btn_P2 = Button(win, text='Partida 2', padx=10, pady=10, command=lambda: guardarPart('2'))
    btn_P2.place(x=220, y=170)

    btn_P3 = Button(win, text='Partida 3', padx=10, pady=10, command=lambda: guardarPart('3'))
    btn_P3.place(x=220, y=230)

    btn_P4 = Button(win, text='Partida 4', padx=10, pady=10, command=lambda: guardarPart('4'))
    btn_P4.place(x=220, y=290)

    btn_P5 = Button(win, text='Partida 5', padx=10, pady=10, command=lambda: guardarPart('5'))
    btn_P5.place(x=220, y=350)

    btn_P6 = Button(win, text='Partida 6', padx=10, pady=10, command=lambda: guardarPart('6'))
    btn_P6.place(x=220, y=410)

    btn_r = Button(win, text='No guardar datos', padx=10, pady=10, command=Menutk)
    btn_r.place(x=200, y=470)

def guardarPart(ssg):
    if ssg == '1':
        a1 = open('slots/slot1.txt', 'w')
        arr1 = [mascota1.tipo, mascota1.nombre, mascota1.salud, mascota1.diversion, mascota1.hambre]
        a1.write(json.dumps(arr1))
        Menutk()
    elif ssg == '2':
        a2 = open('slots/slot2.txt', 'w')
        arr1 = [mascota1.tipo, mascota1.nombre, mascota1.salud, mascota1.diversion, mascota1.hambre]
        a2.write(json.dumps(arr1))
        Menutk()
    elif ssg == '3':
        a3 = open('slots/slot3.txt', 'w')
        arr1 = [mascota1.tipo, mascota1.nombre, mascota1.salud, mascota1.diversion, mascota1.hambre]
        a3.write(json.dumps(arr1))
        Menutk()
    elif ssg == '4':
        a4 = open('slots/slot4.txt', 'w')
        arr1 = [mascota1.tipo, mascota1.nombre, mascota1.salud, mascota1.diversion, mascota1.hambre]
        a4.write(json.dumps(arr1))
        Menutk()
    elif ssg == '5':
        a5 = open('slots/slot5.txt', 'w')
        arr1 = [mascota1.tipo, mascota1.nombre, mascota1.salud, mascota1.diversion, mascota1.hambre]
        a5.write(json.dumps(arr1))
        Menutk()
    elif ssg == '6':
        a6 = open('slots/slot6.txt', 'w')
        arr1 = [mascota1.tipo, mascota1.nombre, mascota1.salud, mascota1.diversion, mascota1.hambre]
        a6.write(json.dumps(arr1))
        Menutk()
    elif ssg == 's':
        Menutk()

def cargar(arr1):
    global mascota1
    if arr1[0] == "gordo":
        mascota1 = gordo()
    elif arr1[0] == "atletico":
        mascota1 = atletico()
    elif arr1[0] == "hiperactivo":
        mascota1 = hiperactivo()

    mascota1.nombre = arr1[1]
    mascota1.salud = arr1[2]
    mascota1.diversion = arr1[3]
    mascota1.hambre = arr1[4]

Menutk()
win.mainloop()