import random
import time

class mascota:
    nombre = ''

    def __init__(self, Salud, Diver, Hambre, Disminucion_diver, Gan_hambre, Tiempo_in, Tipo):
        self.tipo = Tipo
        self.salud = Salud
        self.diversion = Diver
        self.hambre = Hambre
        self.__disminucion_D = Disminucion_diver
        self.__ganancia_H = Gan_hambre
        self.__tiempo = Tiempo_in

    @property
    def Disminucion_diver(self):
        return self.__disminucion_D

    @Disminucion_diver.setter
    def Disminucion_diver(self, nuevaDisDiver):
        self.__disminucion_D = nuevaDisDiver

    @property
    def Gan_hambre(self):
        return self.__ganancia_H

    @Gan_hambre.setter
    def Gan_hambre(self, nuevaGanHambre):
        self.__ganancia_H = nuevaGanHambre

    @property
    def Tiempo_in(self):
        return self.__tiempo

    @Tiempo_in.setter
    def Tiempo_in(self, nuevaIncuba):
        self.__tiempo = nuevaIncuba


    def incubar(self, nom):
        self.Tiempo_in = random.randint(5,10)
        print('Incubando mascota...')
        #time.sleep(self.__tiempo)
        print('Felicidades ha eclosionado el huevo')
        #n = input('Deme el nombre de la nueva mascota: ')
        self.nombre = nom


    def generar_hambre(self): #hilo
        if self.tipo == "gordo":
            if self.hambre >96:
                self.hambre = 100
            else:
                self.hambre += self.__ganancia_H
            self.salud -= 0.35 * self.hambre # PONER .35
        elif self.tipo == 'atletico':
            if self.hambre >92:
                self.hambre = 100
            else:
                self.hambre += self.__ganancia_H
            self.salud -= 0.25*self.hambre  # PONER .25
        elif self.tipo == 'hiperactivo':
            if self.hambre >96:
                self.hambre = 100
            else:
                self.hambre += self.__ganancia_H
            self.salud -= 0.25*self.hambre  # PONER .25

    def generar_aburrimiento(self):
        if self.tipo == "gordo":
            if self.diversion < 4:
                self.diversion = 0
            else:
                self.diversion -= self.__disminucion_D
            self.salud -= (0.18*(100-self.diversion))
        elif self.tipo == 'atletico':
            if self.diversion < 4:
                self.diversion = 0
            else:
                self.diversion -= self.__disminucion_D
            self.salud -= (0.125 * (100 - self.diversion))
        elif self.tipo == 'hiperactivo':
            if self.diversion < 8:
                self.diversion = 0
            else:
                self.diversion -= self.__disminucion_D
            self.salud -= (0.125 * (100 - self.diversion))

    def vet(self):
        if self.salud == 100:
            print('Salud al máximo')
        else:
            if self.salud + 50 > 100:
                self.salud = 100
                self.diversion -= 0.33 * self.diversion
            else:
                self.salud += 50
                self.diversion -= 0.33*self.diversion


    def alimentar(self):
        if self.hambre < 5 and self.hambre > 0:
            #print('Alimentaste a ', self.nombre)
            self.hambre = 0
        elif self.hambre == 0:
            print("La mascota no tiene hambre.")
        else:
            self.hambre -= 5
            print('Alimentaste a ', self.nombre)


    def jugar(self):
        if self.diversion > 95:
            self.diversion = 100
        else:
            self.diversion += 5

    #def mostrar(self):
        #if self.salud <0:
            #self.salud = 0
        #print('\nDatos de la mascota:')
        #print('\tNombre: ', self.nombre )
        #print('\tSalud: ', self.salud )
        #print('\tDiversión: ', self.diversion )
        #print('\tHambre: ', self.hambre )
        #print('\n')


class gordo(mascota): # baja la salud más rápido

    def __init__(self, tipo = 'gordo', Salud=70, Diver=80, Hambre=80, Disminucion_diver=4, Gan_hambre=4, Tiempo_in=0):
        super().__init__(Salud, Diver, Hambre, Disminucion_diver, Gan_hambre, Tiempo_in, tipo)


class hiperactivo(mascota): #baja la diversión más rápido

    def __init__(self,tipo= "hiperactivo", Salud= 60, Diver=50, Hambre=90, Disminucion_diver=8, Gan_hambre=4, Tiempo_in=0):
        super().__init__(Salud, Diver, Hambre, Disminucion_diver, Gan_hambre, Tiempo_in, tipo)


class atletico(mascota):  #Sube el hambre más rápido

    def __init__(self, tipo = "atletico", Salud=90, Diver=80, Hambre=60, Disminucion_diver=4, Gan_hambre=8, Tiempo_in=0):
        super().__init__(Salud, Diver, Hambre, Disminucion_diver, Gan_hambre, Tiempo_in, tipo)
